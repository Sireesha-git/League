package io.kabadi.league.Admin.dashboard.venue;

import org.springframework.data.jpa.repository.JpaRepository;

public interface VenueRepository extends JpaRepository<Venue,Long>{
    
}
