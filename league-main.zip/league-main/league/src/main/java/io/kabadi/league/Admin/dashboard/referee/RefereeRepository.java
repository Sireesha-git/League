package io.kabadi.league.Admin.dashboard.referee;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RefereeRepository extends JpaRepository<Referee,Long>{
    
}
