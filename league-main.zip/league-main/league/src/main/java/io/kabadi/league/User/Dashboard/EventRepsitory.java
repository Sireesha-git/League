package io.kabadi.league.User.Dashboard;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EventRepsitory extends JpaRepository<Event,Long>{
    
}
